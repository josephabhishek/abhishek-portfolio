import type { Metadata } from "next";
import ContactForm from "@/components/ContactForm";
import { SITE } from "@/lib/projects";

export const metadata: Metadata = {
  alternates: { canonical: "/contact" },
  title: "Contact",
  description:
    "Get in touch with Abhishek Joseph — website developer and digital marketer. Start a new build, a rebuild, or a growth project.",
};

export default function ContactPage() {
  const hasEmail = SITE.email && SITE.email !== "hello@example.com";
  const hasLinked = SITE.linkedin && SITE.linkedin !== "#";
  const hasGit = SITE.github && SITE.github !== "#";
  return (
    <>
      <section className="phead wrap" style={{ paddingBottom: "clamp(10px,2vh,24px)" }}>
        <span className="ey rv">// Contact</span>
      </section>
      <section className="wrap sec" style={{ paddingTop: 0 }}>
        <div className="ct-grid">
          <div className="ct-left rv">
            <h1>
              Have something
              <br />
              worth <em>building</em>?
            </h1>
            <p className="lead">
              A new build, a rebuild, or a site that should be ranking and converting better than it
              is. Tell me a little about it &mdash; I&rsquo;ll reply personally.
            </p>
            <div className="ct-detail">
              <a href={hasEmail ? `mailto:${SITE.email}` : "#"}>
                <span className="k">Email</span>
                <span className="v">{hasEmail ? SITE.email : "Add email ↗"}</span>
              </a>
              <a href={SITE.linkedin} target="_blank" rel="noreferrer">
                <span className="k">LinkedIn</span>
                <span className="v">{hasLinked ? "View profile ↗" : "Add profile ↗"}</span>
              </a>
              <a href={SITE.github} target="_blank" rel="noreferrer">
                <span className="k">GitHub</span>
                <span className="v">{hasGit ? "View profile ↗" : "Add profile ↗"}</span>
              </a>
              <div className="row">
                <span className="k">Location</span>
                <span className="v">Mount Abu, Rajasthan &mdash; remote &amp; hybrid</span>
              </div>
              <div className="row">
                <span className="k">Availability</span>
                <span className="v">Open to select freelance &amp; contract work</span>
              </div>
            </div>
          </div>
          <ContactForm />
        </div>
      </section>
    </>
  );
}
